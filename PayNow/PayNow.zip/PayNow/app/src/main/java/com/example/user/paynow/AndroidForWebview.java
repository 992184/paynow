package com.example.user.paynow;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
//웹뷰와 안드로이드 통신 위해서 만든 클래스
//결제 정보 넘겨주어야 함
public class AndroidForWebview {
    Context context;

    public AndroidForWebview(Context c){
        context = c;
    }

    @JavascriptInterface
    public void showToast(String toast) {
        Toast.makeText(context, toast, Toast.LENGTH_SHORT).show();
    }
}
