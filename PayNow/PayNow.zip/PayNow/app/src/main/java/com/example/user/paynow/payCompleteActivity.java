package com.example.user.paynow;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/*
* 결제 마치면 자동으로 여기로 온다.
* */
public class payCompleteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_complete);

        //onClicklistener
        Button.OnClickListener onClickListener = new Button.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(payCompleteActivity.this, MainActivity.class);
                startActivity(intent);
            }
        };

        Button button = (Button)findViewById(R.id.gomainBtn);
        button.setOnClickListener(onClickListener);
    }
}
