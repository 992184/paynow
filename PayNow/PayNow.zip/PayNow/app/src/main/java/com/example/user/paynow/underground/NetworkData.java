package com.example.user.paynow.underground;

/*여기서 IP ADDRESS 컴퓨터와 동일하도록 맞춰 줘야 함*/

public class NetworkData {
    public static String IP_ADDRESS = "172.30.1.25";
    public static String TAG = "payNowtest";
}
