package com.example.user.paynow;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.user.paynow.underground.payWebViewClient;

import java.net.URISyntaxException;

/*
* 결제창이 오픈되는 액티비티
* 액티비티에는 결제를 위한 WebView만 존재한다.
* 해당 WebView에 asset/html 결제 api을 로드해서 결제 진행
* 결제 완료한 return url scheme은 PayCompleteActivity
* */


public class PayActivity extends AppCompatActivity {

    WebView payView;
    private final String APP_SCHEME = "iamportkakao";
    final static String PAY_URL = "file:///android_asset/www/payAPI.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);

        payView = (WebView)findViewById(R.id.payWebView);

/*        WebViewClient webViewClient = new WebViewClient();

        payView.setWebViewClient(webViewClient);  //새 창 없이 액티비티에서 바로 오픈할 수 있게
        payView.setWebChromeClient(new WebChromeClient());  //해당 페이지에서 일어나는 알람 콜백용으로 추가함

        WebSettings payViewSettings = payView.getSettings();

        payViewSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);    //!!TESTCODE!! 웹뷰가 캐시를 사용하지 않도록 test
        payViewSettings.setUseWideViewPort(true);   //??꼭해줘야할까 걍지워돋될듯
        payViewSettings.setJavaScriptEnabled(true) ;    //얜 필수임 js사용

        payViewSettings.setJavaScriptCanOpenWindowsAutomatically(true);//javascript가 window.open()을 사용할 수 있도록 설정
        payViewSettings.setSupportMultipleWindows(true);    //얘도 필요 없을듯
        payViewSettings.setSupportZoom(true);   //눈 안좋은사람들 있을수있으니까 해줌
        payViewSettings.setLoadsImagesAutomatically(true);//웹뷰가 앱에 등록된 이미지 res자동으로 불러올수있도록

        payView.loadUrl("file:///android_asset/www/iamport.html");  //여기까지 제대로 값 넘어가고
*/

        Intent intent = getIntent();
        String total = intent.getStringExtra("total");

        /*제대로 실행되는 거 확인함*/
        payView.setWebViewClient(new payWebViewClient(this));
        payView.addJavascriptInterface(new AndroidForWebview(this), "Android"); //안드로이드 함수를 java에서 쓸 수 있도록.
                                                                                            //Android.function()

        WebSettings settings = payView.getSettings();
        settings.setJavaScriptEnabled(true);

        payView.loadUrl(PAY_URL);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        String url = intent.toString();

        if ( url.startsWith(APP_SCHEME) ) {
            // "iamportapp://https://pgcompany.com/foo/bar"와 같은 형태로 들어옴
            String redirectURL = url.substring(APP_SCHEME.length() + "://".length());
            payView.loadUrl(redirectURL);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        if ( intent != null ) {
            Uri intentData = intent.getData();

            if ( intentData != null ) {
                //카카오페이 인증 후 복귀했을 때 결제 후속조치
                String url = intentData.toString();

                if ( url.startsWith(APP_SCHEME) ) {
                    String path = url.substring(APP_SCHEME.length());
                    if ( "process".equalsIgnoreCase(path) ) {
                        payView.loadUrl("javascript:IMP.communicate({result:'process'})");
                    } else {
                       payView.loadUrl("javascript:IMP.communicate({result:'cancel'})");
                    }
                }
            }
        }

    }


}
