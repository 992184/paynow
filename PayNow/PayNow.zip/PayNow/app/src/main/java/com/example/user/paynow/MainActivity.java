package com.example.user.paynow;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.user.paynow.underground.InsertData;
import com.example.user.paynow.underground.NetworkData;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    NetworkData networkData = new NetworkData();
    String IP_ADDRESS = networkData.IP_ADDRESS;
    String TAG = networkData.TAG;

    Activity currentActivity = this;
    FloatingActionButton fab;
    Button shoppingListBtn;
    Button completeListBtn;
    Button mainPayBtn;

    String barcodeString;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;

        shoppingListBtn = (Button)findViewById(R.id.shoppingListBtn);
        completeListBtn = (Button)findViewById(R.id.completeListBtn);
        mainPayBtn = (Button)findViewById(R.id.mainPayBtn);

        //fab에 바코드 스캔 연결
        fab = (FloatingActionButton) findViewById(R.id.barcodeFAB);

        //onClicklistener
        Button.OnClickListener onClickListener = new Button.OnClickListener(){
            @Override
            public void onClick(View view){

                Intent intent;

                switch(view.getId()){
                    case R.id.barcodeFAB:           //oepn ZXing barcode Scanner Library
                        new IntentIntegrator(currentActivity).initiateScan();
                        break;
                    case R.id.shoppingListBtn:  //go Shopping List Activity
                        intent = new Intent(MainActivity.this, ShoppingListActivity.class);
                        //intent.putExtra(“text”,String.valueOf(editText.getText()));   //넘겨 줄 데이터 이름과 내용
                        startActivity(intent);
                        break;
                    case R.id.completeListBtn:  //go Complete List Activity
                        intent = new Intent(MainActivity.this, CompleteListActivity.class);
                        startActivity(intent);
                        break;
                    case R.id.mainPayBtn:
                        intent = new Intent(MainActivity.this, PayActivity.class);
                        startActivity(intent);
                        break;
                    default:
                        break;
                }
            }
        };

        //connect btn with onClickListener
        fab.setOnClickListener(onClickListener);
        shoppingListBtn.setOnClickListener(onClickListener);
        completeListBtn.setOnClickListener(onClickListener);
        mainPayBtn.setOnClickListener(onClickListener);
    }

    //get result of scan
    //test complete
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {      //if qr doesn't exist
                Toast.makeText(MainActivity.this, "상품을 다시 인식해주세요", Toast.LENGTH_LONG).show();
            } else {                                //if qr exist
                barcodeString = (String) result.getContents();   //스캔한 product code
                Toast.makeText(MainActivity.this, "상품이 인식되었습니다.", Toast.LENGTH_LONG).show();

                /*상품구매여부 ALERT DIALOG*/

               show(barcodeString);

                /*-----------------------------*/
/*
                try {
                    //data를 json으로 변환
                    //!!!!Test!!!!

                    //\\JSONObject obj = new JSONObject(result.getContents());
                    //주석처리했는데 왜 돌아감 돌았나

                    textView.setText("Name: " + obj.getString("name"));
                    textView.append("\nAddress: " + obj.getString("\naddress"));


                } catch (JSONException e) {
                    e.printStackTrace();
                    //Toast.makeText(MainActivity.this, result.getContents(), Toast.LENGTH_LONG).show();
                }
                */
            }

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void show(final String barcodeString) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("상품을 구매하시겠습니까?");
        builder.setMessage(barcodeString + "상품명");
        builder.setPositiveButton("확인",
                new DialogInterface.OnClickListener() {         //제대로 돌아가는 거 확인
                    public void onClick(DialogInterface dialog, int which) {
                        InsertData task = new InsertData(context);
                        task.execute("http://" + IP_ADDRESS + "/insertShoppingList.php", barcodeString);

                        dialog.dismiss();
                        Toast.makeText(getApplicationContext(), "장바구니에 추가되었습니다.", Toast.LENGTH_LONG).show();
                    }
                });
        builder.setNegativeButton("취소",
                new DialogInterface.OnClickListener() {         //
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        new IntentIntegrator(currentActivity).initiateScan();

                        Toast.makeText(getApplicationContext(), "아니오를 선택했습니다.", Toast.LENGTH_LONG).show();
                    }
                });
        builder.show();
    }
}
