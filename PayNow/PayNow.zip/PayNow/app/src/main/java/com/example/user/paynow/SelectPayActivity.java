package com.example.user.paynow;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SelectPayActivity extends AppCompatActivity {
    //여기서 결제방식 선택하도록 구현해야 함
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_pay);
    }
}
